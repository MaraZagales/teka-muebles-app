# Plan de acción — TEKA Muebles

## Criterios obligatorios de desarrollo

- [ ] Validar cada funcionalidad contra los procesos reales de TEKA antes de implementarla.
- [ ] Utilizar los endpoints, campos y reglas existentes sin inventar comportamientos.
- [ ] Diferenciar claramente oportunidad, cliente, carrito, pedido, venta y cobro.
- [ ] Identificar el origen real de cada dato mostrado.
- [ ] Evitar datos hardcodeados, excepto recursos visuales justificados.
- [ ] Implementar cada pantalla con un objetivo funcional definido.
- [ ] Probar el circuito completo antes de considerar terminada una feature.
- [ ] Registrar cualquier decisión funcional pendiente en este plan.

## Estado general del proyecto

- [x] Primera entrega realizada.
- [x] Repositorio creado en GitHub.
- [x] Proyecto actualizado a las versiones recomendadas de Expo SDK 57.
- [x] Expo Doctor validado: 21/21 controles.
- [x] TypeScript validado sin errores.
- [x] Rama `feature/catalogo-busqueda` creada.
- [x] Rama publicada en GitHub.
- [ ] Catálogo, búsqueda y filtros.
- [ ] Detalle de producto.
- [x] Integración inicial con la API.
- [ ] Productos fabricados con recortes.
- [ ] Carrito de compras.
- [ ] Confirmación de compra.
- [ ] Visor 3D.
- [ ] Realidad aumentada.
- [ ] Documentación final del código.
- [ ] Revisión final del README.

---

# Feature 1 — Catálogo, búsqueda y filtros

## Preparación

- [x] Crear la rama `feature/catalogo-busqueda`.
- [x] Actualizar dependencias de Expo SDK 57.
- [x] Ejecutar `npx expo-doctor`.
- [x] Ejecutar `npx tsc --noEmit`.
- [x] Probar la aplicación en Expo Go.
- [x] Guardar y subir la actualización de dependencias.

## Componentes

- [x] Instalar `@expo/vector-icons`.
- [x] Crear el componente `SearchBar`.
- [x] Convertir `CategoryChip` en un componente interactivo.
- [x] Adaptar `ProductCard` para que pueda recibir una acción al presionarlo.
- [x] Crear un componente `EmptyState` para búsquedas sin resultados.
- [x] Revisar si necesitamos un encabezado reutilizable.
- [x] Crear un encabezado reutilizable AppHeader.
- [x] Crear un pie reutilizable AppFooter.
- [x] Centralizar la información del negocio en business-info.ts.

## Integración con datos reales de TEKA

- [x] Crear los tipos correspondientes a productos y precios de la API.
- [x] Configurar la URL base de la API.
- [x] Crear el servicio de productos y precios.
- [x] Instalar y configurar TanStack Query.
- [x] Unificar producto, precio e imagen para la interfaz.
- [x] Mostrar estados de carga, error y sin resultados.
- [x] Consultar categorías reales desde la API.
- [x] Integrar el catálogo inicial con la API.
- [x] Configurar CORS para Expo Web.
- [x] Probar la conexión desde Expo Web.
- [x] Probar la conexión desde el celular físico.

## Pantalla de catálogo

- [x] Crear `src/app/catalogo.tsx`.
- [x] Agregar el título y la descripción de la pantalla.
- [x] Agregar el buscador.
- [x] Agregar las categorías con desplazamiento horizontal.
- [x] Mostrar productos mediante `FlatList`.
- [x] Configurar `keyExtractor`.
- [x] Configurar `renderItem`.
- [x] Mostrar dos columnas con `numColumns`.
- [x] Filtrar productos por categoría.
- [x] Buscar productos por nombre.
- [x] Combinar búsqueda y categoría.
- [x] Mostrar la cantidad de resultados.
- [x] Mostrar un estado vacío cuando no existan coincidencias.
- [x] Limitar la pantalla de Inicio a un máximo de cuatro productos.
- [x] Definir cómo se identifican los productos destacados.
- [x] Mostrar todos los productos únicamente en la pantalla Catálogo.
- [x] Mantener Inicio como una pantalla resumida y comercial.
- [x] Mostrar temporalmente únicamente productos con imagen asociada.
- [x] Mostrar en Inicio un máximo de cuatro productos con imagen.
- [x] Aplicar búsqueda y categorías solamente sobre productos visibles.
- [ ] Verificar que cada imagen corresponda con el producto real de la API.
- [ ] Documentar que el criterio basado en imágenes es temporal.

## Navegación

- [x] Convertir “Ver colección” en un botón funcional.
- [x] Convertir “Ver todas” en un enlace funcional.
- [x] Navegar desde Inicio hacia Catálogo con Expo Router.
- [x] Verificar el botón para volver.
- [x] Confirmar que Inicio continúa funcionando igual.

## Diseño

- [ ] Conservar la paleta crema, verde y madera.
- [ ] Usar valores de `design-tokens.ts`.
- [ ] Mantener espacios basados en múltiplos de cuatro.
- [ ] Mantener radios y tipografías consistentes.
- [ ] Verificar tamaños táctiles mínimos.
- [ ] Probar en diferentes tamaños de celular.
- [ ] Verificar textos largos y nombres de productos.
- [ ] Verificar accesibilidad básica.

## Validaciones técnicas

- [ ] Ejecutar `npx tsc --noEmit`.
- [ ] Ejecutar `npx expo-doctor`.
- [ ] Probar búsqueda por nombre.
- [ ] Probar búsqueda con mayúsculas y minúsculas.
- [ ] Probar cada categoría.
- [ ] Probar búsqueda y categoría simultáneamente.
- [ ] Probar una búsqueda sin coincidencias.
- [ ] Limpiar la búsqueda.
- [ ] Probar navegación desde Inicio.
- [ ] Revisar que no existan errores en la consola.
- [ ] Ejecutar `git status`.
- [ ] Revisar todos los cambios con `git diff`.

## Documentación de la feature

- [ ] Registrar los componentes aplicados de la Clase 2.
- [ ] Explicar el uso de `TextInput`.
- [ ] Explicar el uso de `TouchableOpacity`.
- [ ] Explicar el uso de `FlatList`.
- [ ] Explicar `data`, `renderItem` y `keyExtractor`.
- [ ] Explicar el uso de `useState`.
- [ ] Explicar las props de los componentes reutilizables.
- [ ] Guardar los archivos donde se encuentra cada concepto.
- [ ] Actualizar el estado de la feature en el README.
- [ ] Actualizar la sección de contenidos aplicados del README.

## Cierre de la rama

- [ ] Realizar el commit funcional.
- [ ] Subir la rama a GitHub.
- [ ] Crear un Pull Request.
- [ ] Revisar los archivos modificados.
- [ ] Integrar la rama en `main`.
- [ ] Actualizar el repositorio local.
- [ ] Eliminar la rama cuando ya no sea necesaria.

---

# Feature 2 — Detalle del producto

- [ ] Crear la rama `feature/detalle-producto`.
- [ ] Crear la ruta dinámica `producto/[id].tsx`.
- [ ] Navegar desde `ProductCard`.
- [ ] Mostrar imagen, nombre, categoría y precio.
- [ ] Mostrar descripción, medidas, materiales y colores.
- [ ] Agregar el botón “Agregar al carrito”.
- [ ] Agregar el botón “Ver en tu espacio”.
- [ ] Contemplar producto inexistente.
- [ ] Probar navegación y botón para volver.
- [ ] Ejecutar las validaciones técnicas.
- [ ] Registrar los conceptos aplicados.
- [ ] Actualizar el README.
- [ ] Crear el Pull Request e integrar en `main`.

---

# Feature 3 — API y TanStack Query

- [x] Confirmar la versión vigente de la API de TEKA.
- [x] Confirmar la URL y los endpoints disponibles.
- [x] Instalar TanStack Query.
- [x] Configurar `QueryClientProvider`.
- [x] Crear el servicio de productos.
- [x] Crear los tipos de respuesta de la API.
- [x] Crear el hook `useCatalogData`.
- [x] Implementar `queryKey`.
- [x] Implementar `queryFn`.
- [x] Mostrar `ActivityIndicator`.
- [x] Mostrar estado de error.
- [x] Agregar una acción para reintentar.
- [x] Combinar productos y precios.
- [x] Resolver la asociación con las imágenes.
- [x] Configurar la URL mediante una variable de entorno.
- [x] Probar desde el celular físico.

---

# Feature 4 — Productos fabricados con recortes

- [ ] Analizar los datos reales del módulo Recortes.
- [ ] Definir cómo identificar un producto fabricado con recortes.
- [ ] Crear la rama `feature/productos-recortes`.
- [ ] Agregar un indicador en `ProductCard`.
- [ ] Crear la colección “Hechos con recortes”.
- [ ] Agregar el filtro correspondiente.
- [ ] Mostrar información de sustentabilidad en el detalle.
- [ ] Evitar exponer información interna de producción.
- [ ] Probar la experiencia completa.
- [ ] Actualizar el README.
- [ ] Crear el Pull Request e integrar en `main`.

---

# Feature 5 — Carrito con Zustand

- [ ] Crear la rama `feature/carrito`.
- [ ] Instalar Zustand.
- [ ] Crear `cart-store.ts`.
- [ ] Agregar productos.
- [ ] Evitar productos duplicados.
- [ ] Incrementar cantidades.
- [ ] Disminuir cantidades.
- [ ] Evitar cantidades menores a uno.
- [ ] Eliminar productos.
- [ ] Vaciar el carrito.
- [ ] Calcular unidades totales.
- [ ] Calcular el importe total.
- [ ] Actualizar el indicador del encabezado.
- [ ] Crear la pantalla del carrito.
- [ ] Mostrar el estado de carrito vacío.
- [ ] Registrar los conceptos de Zustand.
- [ ] Actualizar el README.
- [ ] Crear el Pull Request e integrar en `main`.

---

# Feature 6 — Confirmación de compra

- [ ] Crear la rama `feature/confirmacion-compra`.
- [ ] Crear el formulario del comprador.
- [ ] Utilizar `TextInput` controlados.
- [ ] Validar campos obligatorios.
- [ ] Validar correo y teléfono.
- [ ] Mostrar los errores de manera consistente.
- [ ] Mostrar el resumen de la compra.
- [ ] Confirmar el pedido.
- [ ] Evaluar la integración con `POST /api/ventas`.
- [ ] Mostrar resultado exitoso.
- [ ] Manejar errores del servidor.
- [ ] Vaciar el carrito solamente después de confirmar.
- [ ] Actualizar el README.
- [ ] Crear el Pull Request e integrar en `main`.

---

# Feature 7 — Visor 3D y realidad aumentada

- [ ] Investigar compatibilidad con Expo SDK 57.
- [ ] Determinar si requiere un development build.
- [ ] Conseguir modelos 3D de los muebles.
- [ ] Confirmar formatos y medidas reales.
- [ ] Crear primero un visor 3D.
- [ ] Permitir rotar y ampliar el modelo.
- [ ] Crear un prototipo de realidad aumentada.
- [ ] Solicitar permisos de cámara.
- [ ] Colocar el modelo dentro del ambiente.
- [ ] Documentar las limitaciones del prototipo.
- [ ] Actualizar el README.
- [ ] Crear el Pull Request e integrar en `main`.

---

# Documentación final para estudiar el proyecto

- [ ] Explicar el objetivo funcional de la aplicación.
- [ ] Explicar la estructura de carpetas.
- [ ] Explicar cada pantalla.
- [ ] Explicar cada componente reutilizable.
- [ ] Explicar props y estado local.
- [ ] Explicar Expo Router.
- [ ] Explicar `FlatList`.
- [ ] Explicar TanStack Query.
- [ ] Explicar Zustand.
- [ ] Explicar la integración con la API.
- [ ] Explicar el carrito.
- [ ] Explicar las validaciones.
- [ ] Explicar los productos hechos con recortes.
- [ ] Explicar el visor 3D y la realidad aumentada.
- [ ] Relacionar cada concepto con las presentaciones de clase.
- [ ] Indicar en qué archivo se encuentra cada concepto.
- [ ] Incorporar ejemplos pequeños del código real.
- [ ] Crear un glosario.
- [ ] Generar el documento final en formato DOCX.

---

# Revisión final del README

- [ ] Revisar el nombre y la descripción.
- [ ] Revisar los integrantes.
- [ ] Actualizar todas las features.
- [ ] Actualizar el estado real de cada feature.
- [ ] Documentar las tecnologías utilizadas.
- [ ] Documentar la estructura principal.
- [ ] Documentar las variables de entorno.
- [ ] Documentar la conexión con la API.
- [ ] Documentar la ejecución con Expo Go.
- [ ] Documentar el development build si se utiliza.
- [ ] Documentar las limitaciones conocidas.
- [ ] Agregar capturas de las pantallas terminadas.
- [ ] Verificar que otra persona pueda instalar y ejecutar el proyecto.
- [ ] Documentar la configuración del archivo `.env` en el README.
- [ ] Evaluar y realizar el despliegue de la API y la base de datos.
- [ ] Reemplazar la URL local por una URL pública con HTTPS.

## Definición pendiente — clientes y oportunidades comerciales

- [ ] Definir en qué momento una persona interesada pasa a ser cliente.
- [ ] Definir cómo identificar a un cliente existente desde la app.
- [ ] Definir cómo evitar clientes duplicados por documento o correo electrónico.
- [ ] Revisar el alta de clientes mediante `POST /api/clientes`.
- [ ] Definir qué datos mínimos pedirle a un cliente nuevo.
- [ ] Definir si una consulta o intención de compra genera una oportunidad comercial.
- [ ] Registrar oportunidades mediante `POST /api/oportunidades`.
- [ ] Definir el canal de venta correspondiente a la aplicación móvil.
- [ ] Definir cómo representar los productos de interés dentro de la oportunidad.
- [ ] Definir la relación entre oportunidad, carrito, pedido y venta confirmada.
- [ ] Evaluar si el usuario necesita registrarse o puede comprar como invitado.
- [ ] Diseñar las pantallas del flujo de identificación y registro.
- [ ] Servidor de correo para que les lleguen mails a los clientes
- [ ] Revisar que no queden catálogos hardcodeados y tratar de que todos los datos se levante de las tablas primarias y secundarias.
- [ ] Documentar la ejecución local, configuración del `.env` y CORS.
- [ ] Definir el criterio real para publicar un producto en la aplicación.
- [ ] Diferenciar producto activo de producto publicado en la aplicación.
- [ ] Definir dónde se almacenarán las imágenes de productos.
- [ ] Asociar cada imagen con el ProductoId real.
- [ ] Incorporar la URL de la imagen en la respuesta de la API.
- [ ] Reemplazar gradualmente las imágenes locales por imágenes provistas por la API.